/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MsAccessVideo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author Kamlesh
 */
public class Connectionz {
    public static Connection con;
    public static String dbFile = "C://Users//Kamlesh//Downloads//ALL DATAbase//studyviral.mdb";
    public static  String dbUrl="jdbc:ucanaccess://"+dbFile.trim()+";memory=true";
    public static Connection getConnection()
    {
        try{
            con=DriverManager.getConnection(dbUrl,null,null);
            
        }catch(SQLException ex){
            System.out.println(""+ex);
        }
        return con;
    }
    
}
